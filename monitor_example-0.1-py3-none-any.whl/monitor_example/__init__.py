from .Monitor import Monitor
name = "monitor_example"
