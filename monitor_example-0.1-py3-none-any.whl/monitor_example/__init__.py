from .Monitor import Monitor

a = Monitor()
